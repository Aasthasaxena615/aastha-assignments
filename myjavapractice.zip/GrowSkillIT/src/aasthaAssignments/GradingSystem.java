     package aasthaAssignments;

     import java.util.Scanner;
    

public class GradingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input overall marks and math marks
        System.out.print("Enter total marks (0-100): ");
        int totalMarks = scanner.nextInt();

        System.out.print("Enter marks in Maths: ");
        int mathMarks = scanner.nextInt();

        // Grading logic
        if (totalMarks < 20) {
            System.out.println("Grade: Fail");
        } else if (totalMarks >= 20 && totalMarks < 40 && mathMarks < 20) {
            System.out.println("Grade: D");
        } else if (totalMarks >= 40 && totalMarks < 60 && mathMarks < 30) {
            System.out.println("Grade: C");
        } else if (totalMarks >= 60 && totalMarks < 80 && mathMarks < 60) {
            System.out.println("Grade: B");
        } else if (totalMarks >= 80 && totalMarks <= 100 && mathMarks < 80) {
            System.out.println("Grade: A");
        } else {
            System.out.println("Grade: Excellent / Not Applicable based on provided rules");
        }
    }
}
