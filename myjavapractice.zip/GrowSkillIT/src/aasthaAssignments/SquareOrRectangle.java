package aasthaAssignments;
import java.util.Scanner;

public class SquareOrRectangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input length and breadth
        System.out.print("Enter length: ");
        double length = scanner.nextDouble();

        System.out.print("Enter breadth: ");
        double breadth = scanner.nextDouble();

        // Check for square or rectangle
        if (length == breadth) {
            System.out.println("It is a Square.");
        } else {
            System.out.println("It is a Rectangle.");
        }
    }
}
