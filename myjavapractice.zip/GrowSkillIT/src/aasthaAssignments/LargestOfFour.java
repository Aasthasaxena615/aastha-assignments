package aasthaAssignments;


	import java.util.Scanner;

	public class LargestOfFour {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        // Input four numbers
	        System.out.print("Enter first number: ");
	        int a = scanner.nextInt();

	        System.out.print("Enter second number: ");
	        int b = scanner.nextInt();

	        System.out.print("Enter third number: ");
	        int c = scanner.nextInt();

	        System.out.print("Enter fourth number: ");
	        int d = scanner.nextInt();

	        // Find the largest using nested if-else or Math.max
	        int max1 = Math.max(a, b);
	        int max2 = Math.max(c, d);
	        int largest = Math.max(max1, max2);

	        // Display result
	        System.out.println("The largest number is: " + largest);
	    }
	}



