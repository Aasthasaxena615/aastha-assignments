package aasthaAssignments;


	public class MultiplicationTable {
	    public static void main(String[] args) {
	        int number = 29;
	        int i = 1;

	        System.out.println("Multiplication Table of " + number + ":");

	        while (i <= 10) {
	            System.out.println(number + " x " + i + " = " + (number * i));
	            i++;
	        }
	    }
	}
