package aasthaAssignments;


public class FirstTenOddNumbers {
    public static void main(String[] args) {
        System.out.println("First 10 odd numbers:");

        int count = 0;
        int number = 1;

        while (count < 10) {
            System.out.println(number);
            number += 2; // Move to the next odd number
            count++;
        }
    }
}
